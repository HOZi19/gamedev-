extends Label

@export var speed := 200  # pixels per second
var t := 0.0

func _process(delta):
	# Move right
	position.x += speed * delta

	# Wrap around the screen
	if position.x > get_viewport_rect().size.x:
		position.x = -get_size().x  # use get_size() instead of rect_size

	# Pulse brightness (simulated glow)
	t += delta * 3
	var glow = 0.5 + 0.5 * sin(t)  # value from 0 to 1
	modulate = Color(1, 1, 1, glow)  # alpha simulates glow
